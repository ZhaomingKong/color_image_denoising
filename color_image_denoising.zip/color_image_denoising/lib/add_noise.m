function [noise] = add_noise( origin,variance )
%ADD_NOISE Summary of this function goes here
%   Detailed explanation goes here

% max_pixel = max(origin(:));
% 
% origin = origin/double(max_pixel);
% 
% r = variance.*randi(1,size(origin));
% 
% noise = double(origin) + r;
% 
% imshow(noise);

var = variance^2/255^2;
dims = ndims(origin);
noise_less = origin;
if(dims == 2)
    noise_less = imnoise(origin,'gaussian',0,var);
else  
    for i = 1:dims
        noise_less(:,:,i) = imnoise(origin(:,:,i),'gaussian',0,var);
    end
end
noise = noise_less;
% noise = imnoise(origin,'gaussian',0,var);

end

