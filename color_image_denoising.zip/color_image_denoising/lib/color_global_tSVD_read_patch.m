function [im2,psnr,im_ssim] = color_global_tSVD_read_patch(im1,im,ps,SR,sigma,maxK,N_step,modified,tau)
%color_t_hosvd_denoising Summary of this function goes here
%   Detailed explanation goes here
[H,W,D] = size(im);
[U,V] = compute_global(im1,N_step,ps);
info1 = [H,W,D];
info2 = [ps,N_step,SR,maxK];
info3 = [tau,sigma,modified];
tic
[similar_indice] = CPU_search_patch(single(im1),int32(info1),int32(info2), single(info3));
% [similar_indice] =
% GPU_search_patch(single(im1),int32(info1),int32(info2));% complied with
% cuda 7.5, use at your risk.
toc
im2 = color_denoising_global_tSVD(double(im1),int32(similar_indice),double(U),double(V),int32(info1),int32(info2), single(info3));im2 = mat_ten(im2,1,size(im1));
% im2 = color_denoising_hosvd(double(im1),int32(similar_indice),int32(info1),int32(info2), single(info3));im2 = mat_ten(im2,1,size(im1));

im2=double(im2);im=double(im);

mse = sum((im2(:)-im(:)).^2)/(H*W*D);

psnr = 10*log10(255*255/mse);

im_ssim = ssim(im2,im);

end

function [U,V] = compute_global(im1,N_step,ps)
[H,W,D] = size(im1);
count = 0;
for i=1:N_step:H-ps+1 %why start from i=104?
    for j=1:N_step:W-ps+1 %why start from j=49?
        count = count + 1;
        global_indice(count,:) = [i,j];       
    end
end
A = zeros(ps,ps,D,count,'single');
for k=1:count
    yindex = global_indice(k,1);
    xindex = global_indice(k,2);
    A(:,:,:,k) = im1(yindex:yindex+ps-1,xindex:xindex+ps-1,:);
end
[U,V]=NL_tSVD(A);
end

function [U,V] = NL_tSVD(A)
size_A = size(A);ps = size_A(1);N = size_A(end);
A_F = fft(A,[],3);U = zeros(ps,ps,3);V = U;
for i = 1:2
    A_i = A_F(:,:,i,:);
    if(i == 1)
        A_i = real(A_i);
    end
    A1 = my_tenmat(A_i,1);A2 = my_tenmat(A_i,2);
    [Ui,~] = eig(A1*A1');[Vi,~] = eig(A2*A2');
    U(:,:,i) = Ui; V(:,:,i) = Vi;
end
U(:,:,3) = conj(U(:,:,2));V(:,:,3) = conj(V(:,:,2));
end
