

%% here we test if rank has some influence on denoising
% data_folder = 'D:\Data\dnd_2017';
this_path = pwd;
ps = 8;maxK = 30;maxiter = 1;
SR = 20;N_step = 4;modified = 1;
database = 'real_WNNM';
k = 1;
disp(['this code test the t_svd with ps = ',num2str(ps),' maxK = ',num2str(maxK),' SR = ',num2str(SR),' N_step = ',num2str(N_step)]);
%% test real dataset of dnd_2017
% infos = load(fullfile(data_folder, 'info.mat'));
% info = infos.info;
% 
% % iterate over images
% for i=21:30
%     img = load(fullfile(data_folder, 'images_srgb', sprintf('%04d.mat', i)));
%     Inoisy = img.InoisySRGB;
%     
%     % iterate over bounding boxes
%     Idenoised_crop_bbs = cell(1,20);
%     tic
%     for b=1:1
%         bb = info(i).boundingboxes(b,:);
%         Inoisy_crop = Inoisy(bb(1):bb(3), bb(2):bb(4), :);
%         
%         sigma = info(i).sigma_srgb(b);
%         sigma_origin = sigma*255;
%         if(sigma_origin<30)
%             tau = 1.1;
%         else
%             tau = 1.2;
%         end
%         
% %         Idenoised_crop = color_global_tSVD_real(single(Inoisy_crop),ps,SR,sigma,maxK,modified,tau,0,0);
%         Idenoised_crop = color_NLtSVD_my(single(Inoisy_crop),ps,sigma,tau);
% %         Idenoised_crop = CBM3D_real(single(Inoisy_crop),sigma_origin,1);
% %         [im2,Idenoised_crop] = color_global_tSVD_recur_real(single(Inoisy_crop),ps,SR,sigma,maxK,modified,tau,0.4,0.5);
%         Idenoised_crop_bbs{b} = single(Idenoised_crop);
%         figure;imshow(Inoisy_crop);
% %         figure;imshow(im2);
%         figure;imshow(Idenoised_crop);
% %         cd(output_folder);
% %         im_name = strcat('denoised_',num2str(i),'_',num2str(b),'_',num2str(tau),'.png');imwrite(Idenoised_crop,im_name);
% %         im_name = strcat('noisy',num2str(i),'_',num2str(b),'.png');imwrite(Inoisy_crop,im_name);
% %         cd(this_path);
%     end
%     toc
% %     for b=1:1
% %         Idenoised_crop = Idenoised_crop_bbs{b};
% %         str1 = sprintf('%04d_%02d', i, b);str2 = num2str(maxiter);
% %         full_name = strcat(str1,'_maxiter',str2,'.mat');
% % %         save(fullfile(output_folder, sprintf('%04d_%02d.mat', i, b)), 'Idenoised_crop');
% %         save(fullfile(output_folder, full_name), 'Idenoised_crop');
% %     end
% %     fprintf('Image %d/%d done\n', i,50);
% end

%% test real dataset of 'A holistic approach to cross-channel image noise'
addpath('MCWNNM_ICCV2017-master');
addpath('lib');
addpath('MCWNNM_ICCV2017-master\Real_ccnoise_denoised_part/');
GT_Original_image_dir = 'MCWNNM_ICCV2017-master\Real_ccnoise_denoised_part/';
GT_fpath = fullfile(GT_Original_image_dir, '*mean.png');
TT_Original_image_dir = 'MCWNNM_ICCV2017-master\Real_ccnoise_denoised_part/';
TT_fpath = fullfile(TT_Original_image_dir, '*real.png');
GT_im_dir  = dir(GT_fpath);
TT_im_dir  = dir(TT_fpath);
im_num = length(TT_im_dir);
variance = zeros(3,1,'single');
do_wiener = 1;colorspace = 'opp';psnr_cbm3D = 0;
psnr_count = 0;
for i = 1:15
    origin_test = double( imread(fullfile(GT_Original_image_dir, GT_im_dir(i).name)) );
    S = regexp(GT_im_dir(i).name, '\.', 'split');
    fprintf('%s :\n', GT_im_dir(i).name);
    [h, w, ch] = size(origin_test);
    noisy_test = double( imread(fullfile(TT_Original_image_dir, TT_im_dir(i).name)) );
    for c = 1:ch
        variance(c,1) = NoiseEstimation(noisy_test(:, :, c),6);
    end
    sigma = sqrt(sum(variance.^2)/3);
    sigma = 18*sigma;
%     sigma = 30;
%     fprintf('The noise levels are %2.2f, %2.2f, %2.2f. \n', variance(1), variance(2), variance(3) );
%     PSNR =   csnr( noisy_test,origin_test, 0, 0 );
%     SSIM      =  cal_ssim( noisy_test, origin_test, 0, 0 );
%     fprintf('The initial value of PSNR = %2.4f, SSIM = %2.4f \n', PSNR,SSIM);
    tau = 1.1;
    disp(['tau = ',num2str(tau)])
    tic
    [im_t1,psnr_h,im_ssim] = color_global_tSVD_read_patch(single(noisy_test),single(origin_test),ps,SR,sigma,maxK,N_step,modified,tau,database,i);
    time = toc;
    disp([num2str(time),' ',num2str(i),' ',num2str(sigma),' ',num2str(psnr_h),' ',num2str(im_ssim)]);
    psnr_count = psnr_count + psnr_h;
%      figure;imshow(im_t1/255)
    in_name = strcat(num2str(i),'.png');
%     imwrite(uint8(im_t1),in_name);
    
end

% if(strcmp(database,'kodak') == 1)
%     write_path = 'D:\code\denoise\test_denoise\U4_info\kodak';
%     cur_time = fix(clock);cur_para = ['SR = ',num2str(SR),' N_step = ',num2str(N_step),' ps = ',num2str(ps),' maxK = ',num2str(maxK),' tau = ',num2str(tau)];
%     info_para.cur_time = cur_time;info_para.cur_para = cur_para;
%     cd(write_path);
%     save('info_para.mat', '-struct', 'info_para');save('info_para','info_para');
% elseif(strcmp(database,'BSD') == 1)
%     write_path = 'D:\code\denoise\test_denoise\U4_info\BSD';
%     cur_time = fix(clock);cur_para = ['SR = ',num2str(SR),' N_step = ',num2str(N_step),' ps = ',num2str(ps),' maxK = ',num2str(maxK),' tau = ',num2str(tau)];
%     info_para.cur_time = cur_time;info_para.cur_para = cur_para;
%     cd(write_path);
%     save('info_para.mat', '-struct', 'info_para');save('info_para','info_para');
% elseif(strcmp(database,'real_WNNM') == 1)
%     write_path = 'D:\code\denoise\test_denoise\U4_info\real_WNNM';
%     cur_time = fix(clock);cur_para = ['SR = ',num2str(SR),' N_step = ',num2str(N_step),' ps = ',num2str(ps),' maxK = ',num2str(maxK),' tau = ',num2str(tau)];
%     info_para.cur_time = cur_time;info_para.cur_para = cur_para;
%     cd(write_path);
%     save('info_para.mat', '-struct', 'info_para');save('info_para','info_para');
% end

cd(this_path);



