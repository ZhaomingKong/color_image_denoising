

%% here we test if rank has some influence on denoising
addpath('lib');
this_path = pwd;
ps = 8;maxK = 30;SR = 20;
sigma = 30;N_step = 4;delta = 0.4; gamma = 0.5; maxiter = 1;% you could do it recursively using L2 boosting technique...
disp(['this code test the t_svd with ps = ',num2str(ps),' maxK = ',num2str(maxK),' SR = ',num2str(SR),' N_step = ',num2str(N_step)]);
for i = 1:4
    if i < 10
        filename = strcat ('kodak\','kodim0',num2str(i),'.ppm');
    else
        filename = strcat ('kodak\','kodim',num2str(i),'.ppm');
    end
     origin_test = imread(filename);
    for sigma  = 40
        noisy_test = add_noise(origin_test,sigma);
        psnr_noise = psnr(noisy_test,origin_test);
        modified = 1;coef_d1 = 1;
        if(sigma<20)
            tau = 1.1;maxK = maxK;% set tau = 0.8 for hosvd.
        else
            tau = 1.2;maxK = maxK;% set tau = 0.8 for hosvd.
        end
        for tau = tau
        tic
        disp(['using global MNLt_SVD with modified = ',num2str(modified),' tau =  ',num2str(tau)]);
        [im_t1,im_psnr,im_ssim] = color_global_tSVD_read_patch(single(noisy_test),single(origin_test),ps,SR,sigma,maxK,N_step,modified,tau);
        time = toc;
%         figure;imshow(uint8(im_t1));
        disp([num2str(time),' ',num2str(i),' ',num2str(sigma),' ',num2str(psnr_noise),' ',num2str(im_psnr),' ',num2str(im_ssim)]);
        imname = strcat('proposed_kodak_',num2str(i),'_sigma',num2str(sigma),'.png');
        imwrite(uint8(im_t1),imname);
        end
    end
    
end


