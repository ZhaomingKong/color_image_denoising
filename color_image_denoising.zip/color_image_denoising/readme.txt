%%%%%%%%%%%%%%%% about the code %%%%%%%%%%%%%%%%%%%%%%%%%%
1. This code helps you produce competitive color image denoising performance in terms of both efficiency and effectiveness. 
2. The parameters are specified for the dataset indluded in MCWNNM, for synthetic datasets such as kodak gallery or BSD500, use tau = 1.1 when sigma.
3. Use 'GPU_search_patch' for faster speed of patch grouping, but one should be very careful about the compile enviroment (Cuda7.5 is required).
4. The file contains also two state-of-the-art methods for comparison purpose, including our implementation of 4DHOSVD, and the source code of MCWNNM.
5. I am still trying to optimize it, should you have any ideas, please contact me (kong.zm@mail.scut.edu.cn).

%%%%%%%%%%%%%%%% about the author %%%%%%%%%%%%%%%%%%%%%%%%%
I am currently pursuing my master degree at School of Software Engineering, South China University of Technology (SCUT), before that, I got my bachelor degree in Applied Mathematics, also from SCUT.
My research interest mainly includes tensor analysis and its applications in feature extraction. I am also interested in English poems and songs. Besides, I am a super fan of NBA. 